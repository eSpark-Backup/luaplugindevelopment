
local startup = require ("startup")
local timer = require("timer")


timer.reset(5000, timer_id)