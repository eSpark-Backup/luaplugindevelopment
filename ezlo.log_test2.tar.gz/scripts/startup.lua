local logging = require ("logging")
local http = require ("http")


logging.info("The plugin has been removed successfully")
-- http.request{
-- 	url = 'https://webhook.site/7864d08f-2f9d-4ea7-9be7-05252362cc3e',
-- 	handler = 'HUB:ezlo.log_test/scripts/http_handler'
-- }
-- logging.info(print("Milliseconds: " .. socket.gettime()*1000))


-- Importing timer module.
local timer = require("timer")
-- -- Immediately queues ’script_0.lua’ to be executed.
-- timer.set_timeout(0, "HUB:ezlo.minimal/scripts/script_0")
-- Queues ’script_1.lua’ to be executed in 5 seconds.
local timer_id = timer.set_interval(5000, "HUB:ezlo.log_test2/scripts/timer",{arg_name = "timer"})

-- -- Queues ’script_2.lua’ to be executed every 10 seconds.
-- timer.set_interval(10000, "HUB:ezlo.minimal/scripts/script_2")