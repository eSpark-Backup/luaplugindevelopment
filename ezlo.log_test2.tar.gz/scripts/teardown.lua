local _logger = require("logging")
local _http = require("http")

_logger.info("Webhook plugin teardown....")
_logger.info("Removes all devices")
_http.remove_gateway_devices((_http.get_gateway()or{}).id)


_logger.info("clear all storage")
_http.delete_all()
_logger.info("Teardown complete")