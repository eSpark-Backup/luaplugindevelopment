local logger = require("logging")
local http = require("http")

logger.debug("The plugin has been started successfully")
local payload, msg = pcall(http.request, {
    skip_security = true,
    url = "https://webhook.site/7366ae68-d5aa-43b4-bd91-af06139d69dd",
    handler = "HUB:minhttpwaqar1.log_test/scripts/http_handler",
    data = '',
    type = "GET"
})

local payload, msg = pcall(http.request, {
    skip_security = true,
    url = "https://webhook.site/7366ae68-d5aa-43b4-bd91-af06139d69dd",
    handler = "HUB:minhttpwaqar1.log_test/scripts/http_handler",
    data = '',
    type = "POST"
})

local payload, msg = pcall(http.request, {
    skip_security = true,
    url = "https://webhook.site/7366ae68-d5aa-43b4-bd91-af06139d69dd",
    handler = "HUB:minhttpwaqar1.log_test/scripts/http_handler",
    data = '',
    type = "DELETE"
  
})

local payload, msg = pcall(http.request, {
    skip_security = true,
    url = "https://webhook.site/7366ae68-d5aa-43b4-bd91-af06139d69dd",
    handler = "HUB:minhttpwaqar1.log_test/scripts/http_handler",
    data = '',
    type = "PUT"
  
})


local payload, msg = pcall(http.request, {
    skip_security = true,
    url = "https://webhook.site/7366ae68-d5aa-43b4-bd91-af06139d69dd",
    handler = "HUB:minhttpwaqar1.log_test/scripts/http_handler",
    data = '',
    type = "PATCH"
})

if not payload then
    logger.error("Failed to send HTTP request on webhook: " .. msg)
    return false
end


