const dgram = require('dgram');
const client = dgram.createSocket({type:'udp4', reuseAddr:"false"});
const DiscoveryPORT = 4001;
const CommandPORT = 4003;
const serverPORT = 4002;
const MULTICAST_ADDR = '239.255.255.250';
const PORT = 4002;
let SetBrightness = '10';
// const MULTICAST_ADDR = '239.255.255.250';
const scanMsg = '{'+
'  "msg":{'+
'    "cmd":"scan",'+
'    "data":{'+
'      "account_topic":"reserve"'+
'    }'+
'  }'+
'}';

client.send(scanMsg, PORT, MULTICAST_ADDR, (err) => {
  if (err) {
    console.log(err);
  } else {
    console.log('scanMsg sent from client');
  }
});

client.on('message', (msg, rinfo) => {
  console.log(`Client received message: ${msg.toString()} from ${rinfo.address}:${rinfo.port}`);

  let ip;
  const mesg = JSON.parse(msg);

      ip = mesg.msg.data.ip;
      console.log(`ip received message from: ${ip}`);
    
      //*************************************************Condition on Bright******************************************************** */
      if (ip){

        let ColorRED =10;
        let ColorGREEN =50;
        let ColorBLUE =5;
        let ColorTemperature =3000;
        let mESSAGEpayloadRGB = '{' +
        '  "msg":{'+
        '    "cmd":"colorwc",'+
        '    "data":{'+
        '      "color":{'+
        '        "r":'+ColorRED+','+
        '        "g":'+ColorGREEN+','+
        '        "b":'+ColorBLUE+
        '      },'+
        '      "colorTemInKelvin":'+ColorTemperature+
        '    }'+
        '  }'+
        '}';
         //SEND Device RGB and Color Temp
         client.send(mESSAGEpayloadRGB, PORT,MULTICAST_ADDR , (err) => {
          if (err) throw err;
            console.log('Client sent RGB and ColorTemperature Message to Server...');
        client.close();
        });
    }
    else{
        console.log("Try again");
    }
      
});




