const dgram = require('dgram');
const server = dgram.createSocket('udp4');

const PORT = 4003;
const MULTICAST_ADDR = '239.255.255.250';
const DEvicepayload = '  {'+
'    "msg":{ '+
'      "cmd":"scan",'+
'      "data":{'+
'        "ip":"192.168.1.23",'+
'        "device":"1F:80:C5:32:32:36:72:4E",'+
'        "sku":"Hxxxx",'+
'        "bleVersionHard":"3.01.01",'+
'        "bleVersionSoft":"1.03.01",'+
'        "wifiVersionHard":"1.00.10",'+
'        "wifiVersionSoft":"1.02.03"'+
'      }'+
'    }'+
'  }';

server.bind(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
    server.addMembership(MULTICAST_ADDR);
});

server.on('message', (msg, rinfo) => {
  console.log(`Server received message: ${msg.toString()} from ${rinfo.address}:${rinfo.port}`);

    server.send(DEvicepayload, rinfo.port, rinfo.address, (err) => {
      if (err) {
        console.log(err);
      } else {
        console.log('DEvicepayload Message sent from server');
      }
    });
});