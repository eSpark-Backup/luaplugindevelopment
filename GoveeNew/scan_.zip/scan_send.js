const dgram = require('dgram');
const client = dgram.createSocket({type:'udp4', reuseAddr:"false"});

const PORT = 4003;
const MULTICAST_ADDR = '239.255.255.250';
const scanMsg = '{'+
'  "msg":{'+
'    "cmd":"scan",'+
'    "data":{'+
'      "account_topic":"reserve"'+
'    }'+
'  }'+
'}';

client.send(scanMsg, PORT, MULTICAST_ADDR, (err) => {
  if (err) {
    console.log(err);
  } else {
    console.log('scanMsg sent from client');
  }
});

client.on('message', (msg, rinfo) => {
  console.log(`Client received message: ${msg.toString()} from ${rinfo.address}:${rinfo.port}`);
});