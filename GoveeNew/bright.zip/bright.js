const dgram = require('dgram');
const client = dgram.createSocket({type:'udp4', reuseAddr:"false"});
const DiscoveryPORT = 4001;
const CommandPORT = 4003;
const serverPORT = 4002;
const MULTICAST_ADDR = '239.255.255.250';
const PORT = 4002;
let SetBrightness = '10';
// const MULTICAST_ADDR = '239.255.255.250';
const scanMsg = '{'+
'  "msg":{'+
'    "cmd":"scan",'+
'    "data":{'+
'      "account_topic":"reserve"'+
'    }'+
'  }'+
'}';

client.send(scanMsg, PORT, MULTICAST_ADDR, (err) => {
  if (err) {
    console.log(err);
  } else {
    console.log('scanMsg sent from client');
  }
});

client.on('message', (msg, rinfo) => {
  console.log(`Client received message: ${msg.toString()} from ${rinfo.address}:${rinfo.port}`);

  let ip;
  const mesg = JSON.parse(msg);

      ip = mesg.msg.data.ip;
      console.log(`ip received message from: ${ip}`);
    
      //*************************************************Condition on switch******************************************************** */
      if (ip){

        const MESSAGEpayload = 
        '{'+
        '  "msg":{'+
        '    "cmd":"brightness",'+
        '    "data":{'+
        '      "value":'+ SetBrightness +
        '    }'+
        '  }'+
        '}';
        
        
        
        let brightObj = JSON.parse(MESSAGEpayload);
        let brightValue = brightObj.msg.data.value;

        
        client.send(brightValue.toString(), PORT, MULTICAST_ADDR, (err) => {
          if (err) throw err;
          console.log('Client sent message to server...');
        })
        
        client.on('message', (msg, rinfo) => {
          console.log(`brightness is set to : ${brightValue}`);
          //console.log(`Client received message: ${msg.toString()} from ${rinfo.address}:${rinfo.port}`);
          client.close();
        });
    }
    else{
        console.log("Try again");
    }
      
});




