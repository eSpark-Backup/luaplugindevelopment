local logging = require("logging")
 local http = require ("http") 
 local timer = require("timer") 
 num1 = 0
 counter1 = 0


logging.info("The plugin has been configured before HTTP call successfully")





  --i have called in configure.lua
local args = ... or {}
	
	if type(args.num) == "number" and args.num ~= "" then
		num1 = args.num
	else
		logging.info("No Sonos API Running on the URL specified")
		return
	end  
     if(num1 == 0) then
		return
	 end

timer_id = timer.set_interval(5000, "HUB:small.plugin_test/scripts/timercall", {arg_name = "150"}) 


logging.info("The plugin has been configured After HTTP call successfully")


