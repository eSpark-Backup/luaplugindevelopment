local HTTP_handler = require("logging")

logging.info("handler has been called  handler has been called")
logging.info("handler has been called  handler has been called")
logging.info("handler has been called  handler has been called")
logging.info("handler has been called  handler has been called") 



local payload = {   
	labels = { 
		alertname = "luaTest", 
		job = "test",
		cmd = "foo",
		args = "-t test -all -db localhost"
	},  
	annotations = { 
		summary = "cmd exec failed", 
		description = "cmd exec failed, exit code: 2"
	}   
}
local request_body = tostring(payload)--json.encode(payload)
local response_body = {}

-- alertmanager proxyed by nginx with basic auth
local url = "https://webhook.site/1fad94f2-335b-4e3b-aab5-e9532a244a6a"
--[[ local auth = "Basic " .. (mime.b64("name:password")) ]]

local res, code, response_headers = http.request{
url = url,
method = "POST",
headers =
{   
	--[[ ["Authorization"] = auth; ]]
	["Content-Type"] = "application/json";
	["Content-Length"] = #request_body;
},  
--[[ source = ltn12.source.string(request_body), ]]
sink = ltn12.sink.table(response_body),
}

print(res)
print(code)

if type(response_headers) == "table" then
for k, v in pairs(response_headers) do
print(k, v)
end 
end

print("Response body:")
if type(response_body) == "table" then
print(table.concat(response_body))
else
print("Not a table:", type(response_body))
end
