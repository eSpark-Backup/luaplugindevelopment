local logging = require("logging")

logging.info("timer has been called timer has been called")
logging.info("timer has been called timer has been called")
logging.info("timer has been called timer has been called")
logging.info("timer has been called timer has been called")



http.request{
	url = 'http://webhook.site/1fad94f2-335b-4e3b-aab5-e9532a244a6a',
	handler = 'HUB:small.plugin_test/scripts/http_handler'
}


counter1 = counter1 + 1
logging.info("counter in working")
if (counter1 >= num1) then
    timer.cancel(timer_id)
    logging.info("timer has been cancelled")
end

logging.info("Cancelled Cancelled Cancelled") 