local logging = require ("logging")
local http = require ("http")
local timer = require("timer")



local timer_id = timer.set_interval(1000, "HUB:handler", { arg_name = "timer" })

timer.reset(10000, timer_id)

http.request{
	url = 'https://webhook.site/16ea5ddd-a831-456d-a507-7b3486118a55',
	handler = 'HUB:small.plugin_test/scripts/http_handler'
}