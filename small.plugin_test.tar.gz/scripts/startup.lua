local logging = require ("logging")
local http = require ("http") 
--[[ local http  = require("socket.http")  ]]
--[[ local json  = require("json") ]]
--[[ local http  = require("http") ]]
--[[ local ltn12 = require("ltn12") ]]
counter1 = 0



logging.info("The plugin has been started successfully")

 logging.info("The plugin has been started After HTTP call successfully")

